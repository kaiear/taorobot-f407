#ifndef VISION_SORTER_VISION_H
#define VISION_SORTER_VISION_H

#include <array>
#include <optional>
#include <utility>
#include <vector>
#include <string>

#include <opencv2/core.hpp>

namespace vision_sorter {

// VisionConfig 集中保存视觉参数。
// 把阈值和 ROI 放在这里，后面调参时不用去状态机代码里到处找。
struct VisionConfig {
    cv::Size image_size{640, 480};
    cv::Scalar black_low{0, 0, 0};
    cv::Scalar black_high{179, 255, 85};
    std::vector<std::pair<cv::Scalar, cv::Scalar>> red_ranges{
        {cv::Scalar(0, 110, 100), cv::Scalar(10, 255, 255)},
        {cv::Scalar(160, 110, 100), cv::Scalar(179, 255, 255)}
    };
    std::vector<std::array<double, 6>> rois{
        {0, 260, 640, 20, 0.25, 1},
        {0, 130, 640, 20, 0.20, 2},
        {0, 0, 640, 20, 0.10, 3}
    };
    int min_line_area = 400;
    int min_cross_area = 4000;
    int min_red_area = 1000;
};

// Blob 表示图像里识别出来的一块区域。
// center 是中心点，area 是面积，contour 是轮廓点。
struct Blob {
    cv::Point center;
    double area = 0.0;
    std::vector<cv::Point> contour;
};

std::optional<Blob> largestBlob(const cv::Mat& mask, double min_area);
cv::Mat preprocessHsv(const cv::Mat& bgr);
std::optional<Blob> detectRedBlock(const cv::Mat& hsv, const VisionConfig& cfg);
double contourAngleRad(const std::vector<cv::Point>& contour);

// 从 YAML 文件加载视觉配置（例如 image_size, red_ranges, thresholds 等）。
// 使用 OpenCV 的 FileStorage 来读取 YAML 字段，遇到缺失字段时保留默认值。
bool loadVisionConfigFromYaml(const std::string& path, VisionConfig& cfg);

}  // namespace vision_sorter

#endif  // VISION_SORTER_VISION_H

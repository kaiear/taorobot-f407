# 小车巡线和物块分拣 C++ 拆分版

这个目录把原来的单文件程序拆成了多个模块。每个模块只做一类事情，`main.cpp` 负责把它们组合起来。

## 文件说明

- `main.cpp`：程序入口，打开摄像头、串口，并循环调用控制器。
- `args.h/.cpp`：解析命令行参数，例如 `--camera`、`--serial`、`--show`。
- `robot_serial.h/.cpp`：串口通信，发送底盘速度和机械臂 IK 指令。
- `arm_kinematics.h/.cpp`：机械臂逆运动学，把目标位置转换成关节角。
- `vision.h/.cpp`：OpenCV 视觉处理，包括 HSV 预处理、红色物块识别、最大轮廓查找。
- `apriltag_detector.h/.cpp`：AprilTag 可选检测模块，只有编译时加 `-DHAVE_APRILTAG` 才启用。
- `sorter_controller.h/.cpp`：巡线、路口计数、抓取、放置的状态机。
- `common.h`：公共小工具，例如数值限制函数和圆周率常量。
- `build.sh`：一键编译脚本。

## 编译

```bash
cd ~/homework/cpp
chmod +x build.sh
./build.sh
```

只编译普通版时，依赖 OpenCV：

```bash
g++ -std=c++17 -O2 main.cpp args.cpp robot_serial.cpp arm_kinematics.cpp vision.cpp apriltag_detector.cpp sorter_controller.cpp -o vision_sorter $(pkg-config --cflags --libs opencv4)
```

启用 AprilTag：

```bash
g++ -std=c++17 -O2 -DHAVE_APRILTAG main.cpp args.cpp robot_serial.cpp arm_kinematics.cpp vision.cpp apriltag_detector.cpp sorter_controller.cpp -o vision_sorter_apriltag $(pkg-config --cflags --libs opencv4 apriltag)
```

## 运行

无硬件测试摄像头和显示窗口：

```bash
./vision_sorter --camera 0 --dry-run --show
```

上车运行：

```bash
./vision_sorter --camera 0 --serial /dev/ttyUSB0 --baud 115200 --show
```

## 读代码建议

先看 `main.cpp`，理解对象是怎么创建的；再看 `sorter_controller.h`，理解控制器有哪些动作；最后看 `sorter_controller.cpp`，里面是完整的巡线和分拣状态机。

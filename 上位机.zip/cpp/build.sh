#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

SOURCES=(
  "${SCRIPT_DIR}/src/main.cpp"
  "${SCRIPT_DIR}/src/args.cpp"
  "${SCRIPT_DIR}/src/robot_serial.cpp"
  "${SCRIPT_DIR}/src/arm_kinematics.cpp"
  "${SCRIPT_DIR}/src/vision.cpp"
  "${SCRIPT_DIR}/src/apriltag_detector.cpp"
  "${SCRIPT_DIR}/src/sorter_controller.cpp"
)

g++ -std=c++17 -O2 -I"${SCRIPT_DIR}/include" "${SOURCES[@]}" -o "${SCRIPT_DIR}/vision_sorter" \
  $(pkg-config --cflags --libs opencv4)

if pkg-config --exists apriltag; then
  g++ -std=c++17 -O2 -I"${SCRIPT_DIR}/include" -DHAVE_APRILTAG "${SOURCES[@]}" -o "${SCRIPT_DIR}/vision_sorter_apriltag" \
    $(pkg-config --cflags --libs opencv4 apriltag)
fi

echo "Built:"
echo "  ${SCRIPT_DIR}/vision_sorter"
if [[ -x "${SCRIPT_DIR}/vision_sorter_apriltag" ]]; then
  echo "  ${SCRIPT_DIR}/vision_sorter_apriltag"
fi

#include "robot_serial.h"

#include "common.h"

#include <cerrno>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <iostream>
#include <termios.h>
#include <unistd.h>

namespace vision_sorter {

namespace {

// 将波特率整数转换为 termios 的 speed_t 值。
speed_t baudToTermios(int baud) {
    switch (baud) {
        case 9600: return B9600;
        case 19200: return B19200;
        case 38400: return B38400;
        case 57600: return B57600;
        case 115200: return B115200;
        case 230400: return B230400;
        default:
            std::cerr << "unsupported baud " << baud << ", fallback to 115200\n";
            return B115200;
    }
}

}  // namespace

// 构造函数：设置串口路径、波特率与是否为 dry-run 模式。
RobotSerial::RobotSerial(std::string port, int baud, bool dry_run)
    : port_(std::move(port)), baud_(baud), dry_run_(dry_run) {}

// 打开并配置串口设备，返回是否成功。
bool RobotSerial::openPort() {
    if (dry_run_) {
        std::cerr << "[serial] dry-run enabled; frames will not be sent\n";
        return true;
    }

    fd_ = ::open(port_.c_str(), O_RDWR | O_NOCTTY | O_SYNC);
    if (fd_ < 0) {
        std::cerr << "[serial] cannot open " << port_ << ": " << std::strerror(errno) << std::endl;
        return false;
    }

    termios tty{};
    if (tcgetattr(fd_, &tty) != 0) {
        std::cerr << "[serial] tcgetattr failed: " << std::strerror(errno) << std::endl;
        return false;
    }

    cfsetospeed(&tty, baudToTermios(baud_));
    cfsetispeed(&tty, baudToTermios(baud_));
    tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
    tty.c_iflag &= ~IGNBRK;
    tty.c_lflag = 0;
    tty.c_oflag = 0;
    tty.c_cc[VMIN] = 0;
    tty.c_cc[VTIME] = 2;
    tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_cflag |= (CLOCAL | CREAD);
    tty.c_cflag &= ~(PARENB | PARODD);
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CRTSCTS;

    if (tcsetattr(fd_, TCSANOW, &tty) != 0) {
        std::cerr << "[serial] tcsetattr failed: " << std::strerror(errno) << std::endl;
        return false;
    }

    std::cerr << "[serial] opened " << port_ << " @" << baud_ << std::endl;
    return true;
}

// 关闭串口并停止小车。
void RobotSerial::closePort() {
    stop();
    if (fd_ >= 0) {
        ::close(fd_);
        fd_ = -1;
    }
}

// 停止小车（发送零速度）。
void RobotSerial::stop() {
    setVelocity(0.0, 0.0, 0.0);
}

// 发送速度命令到下位机（m/s, m/s, rad/s）。
void RobotSerial::setVelocity(double x, double y, double w) {
    std::vector<uint8_t> frame{0xAA, 0x55, 0x0B, 0x50};
    appendInt16(frame, x * 1000.0);
    appendInt16(frame, y * 1000.0);
    appendInt16(frame, w * 1000.0);
    frame.push_back(checksum(frame, 10));
    writeFrame(frame, "vel");
}

// 发送机械臂逆运动学命令（7 个数值）。
void RobotSerial::sendIk(const std::vector<double>& joints) {
    if (joints.size() != 7) {
        std::cerr << "[serial] IK command requires 7 values\n";
        return;
    }

    std::vector<uint8_t> frame{0xAA, 0x55, 0x13, 0x90};
    for (int i = 0; i < 6; ++i) {
        appendInt16(frame, joints[i] * 1000.0);
    }
    appendUInt16(frame, static_cast<uint16_t>(clampValue<int>(static_cast<int>(joints[6]), 0, 65535)));
    frame.push_back(checksum(frame, 18));
    writeFrame(frame, "ik");
}

// 将一个数值缩放并以大端序写入 frame（2 字节）。
void RobotSerial::appendInt16(std::vector<uint8_t>& frame, double value) {
    int scaled = clampValue<int>(static_cast<int>(std::lround(value)), -32768, 32767);
    uint16_t u = static_cast<uint16_t>(scaled);
    frame.push_back(static_cast<uint8_t>((u >> 8) & 0xFF));
    frame.push_back(static_cast<uint8_t>(u & 0xFF));
}

// 以大端序把无符号 16 位整数写入 frame。
void RobotSerial::appendUInt16(std::vector<uint8_t>& frame, uint16_t value) {
    frame.push_back(static_cast<uint8_t>((value >> 8) & 0xFF));
    frame.push_back(static_cast<uint8_t>(value & 0xFF));
}

// 计算前 count 字节的简单和校验并返回低 8 位。
uint8_t RobotSerial::checksum(const std::vector<uint8_t>& frame, size_t count) {
    uint32_t sum = 0;
    for (size_t i = 0; i < count && i < frame.size(); ++i) {
        sum += frame[i];
    }
    return static_cast<uint8_t>(sum & 0xFF);
}

// 把封装好的帧写入串口，dry-run 模式下打印而不发送。
void RobotSerial::writeFrame(const std::vector<uint8_t>& frame, const char* label) {
    if (dry_run_) {
        static int skip = 0;
        if (++skip % 20 == 0 || std::strcmp(label, "ik") == 0) {
            std::cerr << "[dry-run] " << label << " frame";
            for (uint8_t b : frame) {
                std::cerr << " " << std::hex << static_cast<int>(b) << std::dec;
            }
            std::cerr << std::endl;
        }
        return;
    }

    if (fd_ < 0) {
        return;
    }

    ssize_t n = ::write(fd_, frame.data(), frame.size());
    if (n != static_cast<ssize_t>(frame.size())) {
        std::cerr << "[serial] short write for " << label << std::endl;
    }
}

}  // namespace vision_sorter

#include "apriltag_detector.h"
#include "args.h"
#include "robot_serial.h"
#include "sorter_controller.h"
#include "vision.h"

#include <atomic>
#include <csignal>
#include <iostream>

#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>

namespace {

std::atomic<bool> g_running{true};

void onSignal(int) {
    g_running = false;
}

}  // namespace

// 信号处理函数：收到中断时设置运行标志为 false，主循环将退出。
int main(int argc, char** argv) {
    using namespace vision_sorter;

    std::signal(SIGINT, onSignal);
    std::signal(SIGTERM, onSignal);

    Args args = parseArgs(argc, argv);
    VisionConfig vision;
    // 尝试从 config/camera.yaml 加载视觉配置（如果存在则覆盖默认值）
    if (loadVisionConfigFromYaml(std::string("config/camera.yaml"), vision)) {
        std::cerr << "Loaded vision config from config/camera.yaml\n";
    } else {
        std::cerr << "Using default vision config\n";
    }

    // main.cpp 的职责是“把对象组装起来”：
    // 1. 打开摄像头；
    // 2. 打开串口；
    // 3. 创建控制器；
    // 4. 循环读取图像，把图像交给控制器处理。
    cv::VideoCapture cap(args.camera, cv::CAP_V4L2);
    if (!cap.isOpened()) {
        cap.open(args.camera);
    }
    if (!cap.isOpened()) {
        std::cerr << "cannot open camera index " << args.camera << std::endl;
        return 1;
    }
    cap.set(cv::CAP_PROP_FRAME_WIDTH, vision.image_size.width);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, vision.image_size.height);
    cap.set(cv::CAP_PROP_FPS, 30);

    RobotSerial serial(args.serial_port, args.baud, args.dry_run);
    if (!serial.openPort()) {
        return 1;
    }

    SorterController controller(serial, vision);
    controller.initRobot();

#ifdef HAVE_APRILTAG
    cv::Mat camera_matrix;
    cv::Mat dist_coeff = cv::Mat::zeros(1, 5, CV_64F);
    if (args.fx > 0.0 && args.fy > 0.0 && args.cx > 0.0 && args.cy > 0.0) {
        camera_matrix = (cv::Mat_<double>(3, 3) << args.fx, 0.0, args.cx,
                                                   0.0, args.fy, args.cy,
                                                   0.0, 0.0, 1.0);
    } else {
        std::cerr << "[apriltag] camera intrinsics not provided; tag center is detected but pose is not solved\n";
    }
    AprilTagDetector tag_detector(args.tag_size_m, camera_matrix, dist_coeff);
#else
    std::cerr << "[apriltag] disabled at compile time; using red contour angle only\n";
#endif

    while (g_running) {
        cv::Mat frame;
        if (!cap.read(frame) || frame.empty()) {
            std::cerr << "camera frame read failed\n";
            break;
        }

#ifdef HAVE_APRILTAG
        cv::Mat gray;
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        if (auto tag = tag_detector.detect(gray)) {
            cv::circle(frame, tag->center, 8, cv::Scalar(0, 255, 255), 2);
            cv::Point label_org(static_cast<int>(tag->center.x + 8.0), static_cast<int>(tag->center.y - 8.0));
            std::string label = "tag " + std::to_string(tag->id);
            if (tag->has_pose) {
                label += " z=" + std::to_string(tag->tvec[2]).substr(0, 5) + "m";
            }
            cv::putText(frame, label, label_org,
                        cv::FONT_HERSHEY_SIMPLEX, 0.6, cv::Scalar(0, 255, 255), 2);
        }
#endif

        controller.process(frame);

        if (args.show) {
            cv::imshow("vision_sorter", frame);
            int key = cv::waitKey(1);
            if (key == 27 || key == 'q') {
                break;
            }
        }
    }

    serial.closePort();
    return 0;
}

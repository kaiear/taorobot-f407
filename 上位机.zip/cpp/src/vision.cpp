#include "vision.h"

#include "common.h"

#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>

namespace vision_sorter {

std::optional<Blob> largestBlob(const cv::Mat& mask, double min_area) {
// 找出 mask 中面积最大的连通组件（至少 min_area），返回 Blob 描述。
// 若没有满足条件的组件，返回 std::nullopt。
// 注意：返回的 contour 坐标相对于传入的 mask。
//
// 输入：二值化掩码；输出：包含中心、面积与轮廓的 Blob。
//
// 示例用途：用于检测线段或红色区域。
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    double best_area = 0.0;
    int best_idx = -1;
    for (int i = 0; i < static_cast<int>(contours.size()); ++i) {
        double area = cv::contourArea(contours[i]);
        if (area >= min_area && area > best_area) {
            best_area = area;
            best_idx = i;
        }
    }

    if (best_idx < 0) {
        return std::nullopt;
    }

    cv::Moments m = cv::moments(contours[best_idx]);
    if (m.m00 <= 0.0) {
        return std::nullopt;
    }

    Blob b;
    b.center = cv::Point(static_cast<int>(m.m10 / m.m00), static_cast<int>(m.m01 / m.m00));
    b.area = best_area;
    b.contour = contours[best_idx];
    return b;
}

cv::Mat preprocessHsv(const cv::Mat& bgr) {
// 将 BGR 转为 HSV，并进行开闭运算去噪，返回处理后的 HSV 图像。
    cv::Mat hsv;
    cv::cvtColor(bgr, hsv, cv::COLOR_BGR2HSV);

    // 先腐蚀再膨胀可以去掉小噪点。
    // 这里保持原程序的 5x5 核，效率和效果都不变。
    cv::Mat kernel = cv::Mat::ones(5, 5, CV_8U);
    cv::erode(hsv, hsv, kernel, cv::Point(-1, -1), 1);
    cv::dilate(hsv, hsv, kernel, cv::Point(-1, -1), 1);
    return hsv;
}

std::optional<Blob> detectRedBlock(const cv::Mat& hsv, const VisionConfig& cfg) {
// 在 hsv 图像中根据 cfg.red_ranges 合并红色 mask，然后在配置的 ROI 内
// 查找最大的红色块，若找到则返回其 Blob，否则返回 std::nullopt。
    cv::Mat mask = cv::Mat::zeros(hsv.size(), CV_8U);
    for (const auto& range : cfg.red_ranges) {
        cv::Mat one;
        cv::inRange(hsv, range.first, range.second, one);
        mask |= one;
    }

    cv::Rect roi(0, 0, 640, 300);
    roi &= cv::Rect(0, 0, hsv.cols, hsv.rows);
    auto blob = largestBlob(mask(roi), cfg.min_red_area);
    if (!blob.has_value()) {
        return std::nullopt;
    }

    blob->center.x += roi.x;
    blob->center.y += roi.y;
    for (auto& p : blob->contour) {
        p.x += roi.x;
        p.y += roi.y;
    }
    return blob;
}

double contourAngleRad(const std::vector<cv::Point>& contour) {
// 计算轮廓的最小外接旋转矩形并返回其角度（弧度）。
// 若轮廓点太少则返回 0。
    if (contour.size() < 4) {
        return 0.0;
    }

    cv::RotatedRect rect = cv::minAreaRect(contour);
    double angle = rect.angle;
    if (angle < -45.0) {
        angle += 90.0;
    } else if (angle > 45.0) {
        angle -= 90.0;
    }
    return -angle * kPi / 180.0;
}

bool loadVisionConfigFromYaml(const std::string& path, VisionConfig& cfg) {
    cv::FileStorage fs(path, cv::FileStorage::READ);
    if (!fs.isOpened()) return false;

    auto readScalar = [](const cv::FileNode& node, cv::Scalar& s) {
        if (node.isSeq() && node.size() >= 3) {
            s[0] = static_cast<double>(node[0]);
            s[1] = static_cast<double>(node[1]);
            s[2] = static_cast<double>(node[2]);
        }
    };

    cv::FileNode n = fs["image_size"];
    if (!n.empty()) {
        int w = static_cast<int>(n["width"]);
        int h = static_cast<int>(n["height"]);
        if (w > 0 && h > 0) cfg.image_size = cv::Size(w, h);
    }

    readScalar(fs["black_low"], cfg.black_low);
    readScalar(fs["black_high"], cfg.black_high);

    cv::FileNode rr = fs["red_ranges"];
    if (!rr.empty()) {
        cfg.red_ranges.clear();
        for (const auto& item : rr) {
            if (item.size() >= 2) {
                cv::Scalar a, b;
                readScalar(item[0], a);
                readScalar(item[1], b);
                cfg.red_ranges.emplace_back(a, b);
            }
        }
    }

    cv::FileNode rois = fs["rois"];
    if (!rois.empty()) {
        cfg.rois.clear();
        for (const auto& r : rois) {
            if (r.size() >= 6) {
                std::array<double, 6> arr;
                for (int i = 0; i < 6; ++i) arr[i] = static_cast<double>(r[i]);
                cfg.rois.push_back(arr);
            }
        }
    }

    if (fs["min_line_area"].isInt()) cfg.min_line_area = static_cast<int>(fs["min_line_area"]);
    if (fs["min_cross_area"].isInt()) cfg.min_cross_area = static_cast<int>(fs["min_cross_area"]);
    if (fs["min_red_area"].isInt()) cfg.min_red_area = static_cast<int>(fs["min_red_area"]);

    return true;
}

}  // namespace vision_sorter
